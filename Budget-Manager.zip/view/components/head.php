<head>
  <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta property="og:title" content="Jobick : Job Admin Bootstrap 5 Template" />
	<meta property="og:description" content="Jobick : Job Admin Bootstrap 5 Template" />
	<meta property="og:image" content="https://jobick.dexignlab.com/xhtml/social-image.png" />
	<meta name="format-detection" content="telephone=no">

	<!-- PAGE TITLE HERE -->
	<title>Budget Manager - El Lugar</title>

	<!-- FAVICONS ICON -->
	<link rel="icon" type="image/png" href="http://cdn.mcauto-images-production.sendgrid.net/5e4c42c90c127f93/69592712-ca76-4666-80a5-269b6b76e6fd/377x374.png" />

  <script src="<?=ASSETS?>vendor/jquery/jquery.min.js"></script>
  <link href="<?=ASSETS?>vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
  <link href="<?=ASSETS?>css/style.css" rel="stylesheet">
  <link href="<?=ASSETS?>vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
  <link href="<?=ASSETS?>icons/flaticon/flaticon.css" rel="stylesheet">
  <link href="<?=ASSETS?>vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
  <link href="<?=ASSETS?>vendor/sweetalert2/dist/sweetalert2.min.css" rel="stylesheet">
  <script src="<?=ASSETS?>vendor/apexchart/apexchart.js"></script>
  <script src="<?=ASSETS?>vendor/moment/moment.min.js"></script>
  <link href="<?=ASSETS?>vendor/jquery-asColorPicker/css/asColorPicker.min.css" rel="stylesheet">

  <link href="<?=ASSETS?>vendor/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet">
  <script src="<?=ASSETS?>vendor/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>


</head>
