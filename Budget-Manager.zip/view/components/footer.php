<div class="footer">
  <div class="copyright">
    <!-- <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2021</p> -->
  </div>
</div>


<script src="<?=ASSETS?>vendor/global/global.min.js"></script>
<script src="<?=ASSETS?>vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>
<script src="<?=ASSETS?>vendor/chart.js/Chart.bundle.min.js"></script>
<script src="<?=ASSETS?>vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?=ASSETS?>vendor/sweetalert2/dist/sweetalert2.min.js"></script>
<script src="<?=ASSETS?>js/custom.min.js"></script>
<script src="<?=ASSETS?>js/dlabnav-init.js"></script>
<script src="<?=ASSETS?>vendor/peity/jquery.peity.min.js"></script>
<script src="<?=ASSETS?>vendor/chartist/js/chartist.min.js"></script>
<script src="<?=ASSETS?>vendor/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js"></script>
<script src="<?=ASSETS?>vendor/jquery-asColor/jquery-asColor.min.js"></script>
<script src="<?=ASSETS?>vendor/jquery-asGradient/jquery-asGradient.min.js"></script>
<script src="<?=ASSETS?>vendor/jquery-asColorPicker/js/jquery-asColorPicker.min.js"></script>
