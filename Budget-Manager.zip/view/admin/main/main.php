<h2> ADMIN PANEL </h2>
<a href="controller/doLogout.php">Logout</a>
<br><br>
<a href="?<?=EXIT_ADMIN?>">Go To Client</a>
